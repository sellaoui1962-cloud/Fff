package com.example.jumpbot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp(), 48.dp(), 24.dp(), 24.dp())
            setBackgroundColor(Color.WHITE)
        }
        fun title(t: String) = TextView(this).apply {
            text = t; textSize = 26f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
        }
        fun button(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }
        root.addView(title("قفز بوت"))
        status = TextView(this).apply { textSize = 16f; setPadding(0, 24.dp(), 0, 24.dp()); setTextColor(Color.DKGRAY) }
        root.addView(status)
        root.addView(button("1) السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("2) تفعيل خدمة الوصول (قفز بوت)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3) بدء الالتقاط والتحكم") { start() })
        root.addView(button("إيقاف البوت") {
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        })
        root.addView(TextView(this).apply {
            textSize = 14f; setPadding(0, 24.dp(), 0, 0); setTextColor(Color.GRAY)
            text = "بعد البدء افتح اللعبة. ستظهر لوحة عائمة: ▶ ابدأ / − + لضبط K / تعلّم / ✕.\n" +
                    "المربعات الخضراء = القطع الأمامية، الأصفر = القطعة الحالية، الدائرة الحمراء = اللاعب، " +
                    "والخط الأخضر السميك = الهدف ومنه تُحسب مدة الضغط."
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        val acc = BotAccessibilityService.instance != null
        val cap = CaptureService.running
        status.text = "الظهور فوق التطبيقات: ${if (ov) "✅" else "❌"}\n" +
                "خدمة الوصول: ${if (acc) "✅" else "❌"}\n" +
                "الالتقاط: ${if (cap) "✅ يعمل" else "متوقف"}"
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { toast("فعّل الخطوة 1 أولاً"); return }
        if (BotAccessibilityService.instance == null) { toast("فعّل الخطوة 2 أولاً"); return }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            )
            toast("تم البدء — افتح اللعبة")
            moveTaskToBack(true)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
