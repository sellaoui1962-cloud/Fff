package com.example.jumpbot

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** صندوق كتلة؛ (cx, cy) = مركز الوجه العلوي في منظور أيزومتري (ارتفاعه ≈ نصف عرضه). */
data class Box(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
    val w get() = x1 - x0
    val cx get() = (x0 + x1) / 2f
    val cy get() = y0 + w / 4f
}

data class Analysis(
    val px: Float, val py: Float,       // قدما اللاعب
    val cur: Box?,                      // القطعة التي يقف عليها
    val ahead: List<Box>,               // القطع الأمامية (مرشّحة)
    val target: Box?,                   // الهدف المختار
    val below: Box?                     // القطعة السابقة (للمعايرة)
)

object Detector {

    private class Comp(var x0: Int, var y0: Int, var x1: Int, var y1: Int, var count: Int, var sumX: Long)

    private fun dilate(src: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val W = w + 1
        val ii = IntArray(W * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                if (src[y * w + x]) row++
                ii[(y + 1) * W + x + 1] = ii[y * W + x + 1] + row
            }
        }
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            val ya = max(0, y - r); val yb = min(h, y + r + 1)
            for (x in 0 until w) {
                val xa = max(0, x - r); val xb = min(w, x + r + 1)
                val s = ii[yb * W + xb] - ii[ya * W + xb] - ii[yb * W + xa] + ii[ya * W + xa]
                out[y * w + x] = s > 0
            }
        }
        return out
    }

    private fun erode(src: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val inv = BooleanArray(src.size) { !src[it] }
        val d = dilate(inv, w, h, r)
        return BooleanArray(src.size) { !d[it] }
    }

    private fun closing(m: BooleanArray, w: Int, h: Int, r: Int) = erode(dilate(m, w, h, r), w, h, r)
    private fun opening(m: BooleanArray, w: Int, h: Int, r: Int) = dilate(erode(m, w, h, r), w, h, r)

    private fun label(m: BooleanArray, w: Int, h: Int): Pair<IntArray, List<Comp>> {
        val lab = IntArray(w * h)
        val comps = ArrayList<Comp>()
        val stack = IntArray(w * h)
        for (s in 0 until w * h) {
            if (!m[s] || lab[s] != 0) continue
            val id = comps.size + 1
            val c = Comp(s % w, s / w, s % w, s / w, 0, 0)
            var sp = 0
            stack[sp++] = s; lab[s] = id
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                c.count++; c.sumX += x
                if (x < c.x0) c.x0 = x
                if (x > c.x1) c.x1 = x
                if (y < c.y0) c.y0 = y
                if (y > c.y1) c.y1 = y
                if (x > 0 && m[p - 1] && lab[p - 1] == 0) { lab[p - 1] = id; stack[sp++] = p - 1 }
                if (x < w - 1 && m[p + 1] && lab[p + 1] == 0) { lab[p + 1] = id; stack[sp++] = p + 1 }
                if (y > 0 && m[p - w] && lab[p - w] == 0) { lab[p - w] = id; stack[sp++] = p - w }
                if (y < h - 1 && m[p + w] && lab[p + w] == 0) { lab[p + w] = id; stack[sp++] = p + w }
            }
            comps.add(c)
        }
        return Pair(lab, comps)
    }

    private fun median(hist: IntArray, half: Int): Int {
        var acc = 0
        for (i in 0..255) { acc += hist[i]; if (acc > half) return i }
        return 255
    }

    /** pix = ARGB بحجم w×h (مُصغّرة للنصف). */
    fun analyze(pix: IntArray, w: Int, h: Int): Analysis? {
        val top = (h * 0.20).toInt()
        val botPlayer = (h * 0.88).toInt()
        val botBlocks = (h * 0.90).toInt()

        // 1) اللاعب: كحلي داكن
        val pm = BooleanArray(w * h)
        for (y in top until botPlayer) for (x in 0 until w) {
            val c = pix[y * w + x]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (max(r, max(g, b)) < 120 && b >= r + 8) pm[y * w + x] = true
        }
        val pc = closing(pm, w, h, 2)
        val (plab, pcomps) = label(pc, w, h)
        if (pcomps.isEmpty()) return null
        var bi = 0
        for (i in pcomps.indices) if (pcomps[i].count > pcomps[bi].count) bi = i
        val pcmp = pcomps[bi]
        if (pcmp.count < 30) return null
        val px = pcmp.sumX.toFloat() / pcmp.count
        val py = pcmp.y1 - 3f
        val pmask = BooleanArray(w * h) { plab[it] == bi + 1 }
        val pdil = dilate(pmask, w, h, 3)

        // 2) القطع: ما يختلف عن لون الخلفية (وسيط الصف)
        val fg = BooleanArray(w * h)
        val hr = IntArray(256); val hg = IntArray(256); val hb = IntArray(256)
        val half = w / 2
        for (y in top until botBlocks) {
            java.util.Arrays.fill(hr, 0); java.util.Arrays.fill(hg, 0); java.util.Arrays.fill(hb, 0)
            for (x in 0 until w) {
                val c = pix[y * w + x]
                hr[(c shr 16) and 255]++; hg[(c shr 8) and 255]++; hb[c and 255]++
            }
            val mr = median(hr, half); val mg = median(hg, half); val mb = median(hb, half)
            for (x in 0 until w) {
                val c = pix[y * w + x]
                val d = abs(((c shr 16) and 255) - mr) + abs(((c shr 8) and 255) - mg) + abs((c and 255) - mb)
                if (d > 45 && !pdil[y * w + x]) fg[y * w + x] = true
            }
        }
        val clean = opening(closing(fg, w, h, 2), w, h, 2)
        val (_, comps) = label(clean, w, h)
        val blocks = comps
            .filter { it.x1 - it.x0 + 1 >= 45 && it.y1 - it.y0 + 1 >= 30 }
            .map { Box(it.x0, it.y0, it.x1 + 1, it.y1 + 1) }
        if (blocks.isEmpty()) return null

        // 3) الحالية = الأقرب لقدمي اللاعب
        val cur = blocks.minByOrNull { hypot(it.cx - px, it.cy - py) }!!
        val ahead = blocks.filter { it !== cur && it.cy < py - 10 }
        val target = ahead.minByOrNull { hypot(it.cx - px, it.cy - py) }
        val below = blocks
            .filter { it !== cur && it.cy > py + 10 && it.y1 < botPlayer }
            .minByOrNull { hypot(it.cx - px, it.cy - py) }
        return Analysis(px, py, cur, ahead, target, below)
    }

    /** زر "العب مجدداً" الأصفر بعد الخسارة. */
    fun gameOverButton(pix: IntArray, w: Int, h: Int): Pair<Int, Int>? {
        var n = 0; var sx = 0L; var sy = 0L
        for (y in (h * 0.55).toInt() until (h * 0.80).toInt()) for (x in 0 until w) {
            val c = pix[y * w + x]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (r > 220 && g > 170 && b < 90) { n++; sx += x; sy += y }
        }
        return if (n > 500) Pair((sx / n).toInt(), (sy / n).toInt()) else null
    }
}
