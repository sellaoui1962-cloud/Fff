package com.example.jumpbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.hypot

class CaptureService : Service() {

    companion object {
        @Volatile var running = false
    }

    private class Prev(val d: Float)

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var imgThread: HandlerThread? = null
    private var worker: Thread? = null
    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var panel: LinearLayout? = null
    private var info: TextView? = null
    private var toggleBtn: TextView? = null
    private var learnBtn: TextView? = null

    @Volatile private var frame: IntArray? = null
    @Volatile private var frameTime = 0L
    @Volatile private var alive = false
    @Volatile private var botOn = false
    @Volatile private var learn = true
    @Volatile private var k = 1350f      // مللي ثانية لكل (مسافة ÷ عرض الشاشة)
    @Volatile private var last = ""

    private var sw = 0; private var sh = 0
    private var fw = 0; private var fh = 0

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        startFg()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        fw = sw / 2; fh = sh / 2

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        imgThread = HandlerThread("img").also { it.start() }
        reader = ImageReader.newInstance(fw, fh, PixelFormat.RGBA_8888, 3).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
                try {
                    val pl = img.planes[0]
                    val buf = pl.buffer
                    val rs = pl.rowStride; val ps = pl.pixelStride
                    val out = IntArray(fw * fh)
                    for (y in 0 until fh) {
                        var o = y * rs
                        for (x in 0 until fw) {
                            val r8 = buf.get(o).toInt() and 255
                            val g8 = buf.get(o + 1).toInt() and 255
                            val b8 = buf.get(o + 2).toInt() and 255
                            out[y * fw + x] = (255 shl 24) or (r8 shl 16) or (g8 shl 8) or b8
                            o += ps
                        }
                    }
                    frame = out
                    frameTime = SystemClock.uptimeMillis()
                } finally { img.close() }
            }, Handler(imgThread!!.looper))
        }
        vd = projection!!.createVirtualDisplay(
            "jb", fw, fh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        buildOverlay()
        buildPanel()
        running = true
        alive = true
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jb", "Jump Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jb")
            .setContentTitle("قفز بوت يعمل")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ------------------------------------------------------------ الواجهة العائمة
    private fun buildOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        overlay = v
    }

    private fun btn(t: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        setPadding(14.dp(), 8.dp(), 14.dp(), 8.dp())
        setBackgroundColor(Color.rgb(55, 71, 79))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            gravity = Gravity.CENTER_VERTICAL
        }
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(3.dp(), 0, 3.dp(), 0)
            p.addView(v, lp)
        }
        toggleBtn = btn("▶ ابدأ") {
            botOn = !botOn
            toggleBtn?.text = if (botOn) "⏸ أوقف" else "▶ ابدأ"
        }
        add(toggleBtn!!)
        add(btn("−") { k = (k - 25f).coerceAtLeast(300f); refreshInfo() })
        add(btn("+") { k = (k + 25f).coerceAtMost(4000f); refreshInfo() })
        learnBtn = btn("تعلّم: نعم") {
            learn = !learn
            learnBtn?.text = if (learn) "تعلّم: نعم" else "تعلّم: لا"
        }
        add(learnBtn!!)
        add(btn("✕") { stopSelf() })
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f }
        add(info!!)
        refreshInfo()

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = 70.dp()
        wm.addView(p, lp)
        panel = p
    }

    private fun refreshInfo() {
        main.post { info?.text = "K=${k.toInt()}  $last" }
    }

    // ------------------------------------------------------------ الحلقة الرئيسية
    /** يخفي الطبقة الخضراء ثم يأخذ لقطة نظيفة (كي لا يخلط البوت المربعات بالقطع). */
    private fun grab(): IntArray? {
        val latch = CountDownLatch(1)
        main.post { overlay?.visibility = View.INVISIBLE; latch.countDown() }
        latch.await(500, TimeUnit.MILLISECONDS)
        val t = SystemClock.uptimeMillis()
        var waited = 0
        while (frameTime < t + 50 && waited < 600) { Thread.sleep(20); waited += 20 }
        return frame
    }

    private fun show(a: Analysis?, label: String) {
        main.post {
            overlay?.let {
                it.res = a; it.scale = sw.toFloat() / fw; it.label = label
                it.visibility = View.VISIBLE
                it.invalidate()
            }
        }
    }

    private fun loop() {
        var stable = 0
        var lastPx = -1f; var lastPy = -1f
        var prev: Prev? = null
        val pressX = sw * 0.5f
        val pressY = sh * 0.78f

        while (alive) {
            try {
                val f = grab()
                if (f == null) { Thread.sleep(300); continue }

                if (botOn) {
                    val b = Detector.gameOverButton(f, fw, fh)
                    if (b != null) {
                        last = "إعادة اللعب"; refreshInfo()
                        BotAccessibilityService.hold(b.first * 2f, b.second * 2f, 60)
                        Thread.sleep(2500)
                        prev = null; stable = 0
                        continue
                    }
                }

                val a = Detector.analyze(f, fw, fh)
                val target = a?.target
                if (a == null || target == null) {
                    show(a, ""); stable = 0
                    last = "لا أجد اللاعب/الهدف"; refreshInfo()
                    Thread.sleep(250); continue
                }

                val dist = hypot(target.cx - a.px, target.cy - a.py) / fw
                val moved = hypot(a.px - lastPx, a.py - lastPy)
                lastPx = a.px; lastPy = a.py
                stable = if (moved < 3f) stable + 1 else 0

                // معايرة ذاتية: قارن المسافة المتوقعة بالفعلية للقفزة السابقة
                val p = prev
                if (learn && p != null && a.below != null && stable >= 1) {
                    val actual = hypot(a.px - a.below.cx, a.py - a.below.cy) / fw
                    if (actual in 0.12f..1.2f) {
                        val ratio = p.d / actual
                        if (ratio in 0.65f..1.5f) k = (0.8f * k + 0.2f * k * ratio).coerceIn(300f, 4000f)
                    }
                    prev = null
                }

                val ms = (k * dist).coerceIn(80f, 3500f)
                show(a, "${ms.toInt()}ms")
                last = "مسافة=${(dist * 100).toInt()}%  ضغط=${ms.toInt()}ms"
                refreshInfo()

                if (!botOn || stable < 2) { Thread.sleep(150); continue }

                if (!BotAccessibilityService.hold(pressX, pressY, ms.toLong())) {
                    last = "فعّل خدمة الوصول!"; refreshInfo(); Thread.sleep(1000); continue
                }
                prev = Prev(dist)
                stable = 0
                Thread.sleep(1100)
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                last = "خطأ: ${e.javaClass.simpleName}"; refreshInfo()
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            }
        }
    }

    override fun onDestroy() {
        alive = false
        running = false
        worker?.interrupt()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        imgThread?.quitSafely()
        super.onDestroy()
    }
}
