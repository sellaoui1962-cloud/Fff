package com.example.jumpbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null

        /** ضغط مطوّل (أو نقرة) في نقطة، ويرجع بعد انتهاء الإيماءة. */
        fun hold(x: Float, y: Float, ms: Long): Boolean {
            val svc = instance ?: return false
            val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, ms.coerceAtLeast(1))
            val g = GestureDescription.Builder().addStroke(stroke).build()
            val latch = CountDownLatch(1)
            var ok = false
            val accepted = svc.dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)
            if (!accepted) return false
            latch.await(ms + 3000, TimeUnit.MILLISECONDS)
            return ok
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
