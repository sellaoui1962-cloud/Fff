package com.example.jumpbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** طبقة رسم فوق اللعبة: مربعات خضراء للقطع الأمامية + خطوط من اللاعب. */
class OverlayView(c: Context) : View(c) {
    var res: Analysis? = null
    var scale = 2f
    var label = ""

    private fun stroke(col: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col; style = Paint.Style.STROKE; strokeWidth = w
    }
    private val green = stroke(Color.rgb(0, 230, 118), 6f)
    private val greenBold = stroke(Color.rgb(0, 255, 100), 12f)
    private val greenFill = Paint().apply { color = Color.argb(70, 0, 230, 118); style = Paint.Style.FILL }
    private val yellow = stroke(Color.YELLOW, 6f)
    private val thin = stroke(Color.argb(160, 255, 255, 255), 3f)
    private val red = stroke(Color.RED, 8f)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 42f; setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }

    override fun onDraw(c: Canvas) {
        val a = res ?: return
        val s = scale
        val px = a.px * s; val py = a.py * s
        a.cur?.let { c.drawRect(it.x0 * s, it.y0 * s, it.x1 * s, it.y1 * s, yellow) }
        for (b in a.ahead) {
            c.drawRect(b.x0 * s, b.y0 * s, b.x1 * s, b.y1 * s, green)
            c.drawLine(px, py, b.cx * s, b.cy * s, thin)
        }
        a.target?.let {
            c.drawRect(it.x0 * s, it.y0 * s, it.x1 * s, it.y1 * s, greenFill)
            c.drawLine(px, py, it.cx * s, it.cy * s, greenBold)
            c.drawCircle(it.cx * s, it.cy * s, 14f, greenBold)
            c.drawText(label, (px + it.cx * s) / 2f + 20f, (py + it.cy * s) / 2f, text)
        }
        c.drawCircle(px, py, 20f, red)
    }
}
