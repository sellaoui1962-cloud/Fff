package com.example.jumpbot

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/** ثيم رمادي عصري. */
object Theme {
    val BG = Color.parseColor("#16171A")
    val CARD = Color.parseColor("#212327")
    val CARD2 = Color.parseColor("#2C2F34")
    val LINE = Color.parseColor("#3A3E44")
    val TEXT = Color.parseColor("#ECEFF1")
    val SUB = Color.parseColor("#9AA0A6")
    val ACCENT = Color.parseColor("#C9CED4")
    val ON_ACCENT = Color.parseColor("#16171A")
    val OK_BG = Color.parseColor("#26372D")
    val OK_FG = Color.parseColor("#8FE3A8")
    val BAD_BG = Color.parseColor("#3A2A2A")
    val BAD_FG = Color.parseColor("#E8A0A0")

    fun shape(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radiusPx
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun oval(color: Int, strokeColor: Int, strokePx: Int) =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color); setStroke(strokePx, strokeColor)
        }
}

fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()
