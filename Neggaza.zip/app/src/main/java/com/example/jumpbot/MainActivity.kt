package com.example.jumpbot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var chipOv: TextView
    private lateinit var chipAcc: TextView
    private lateinit var chipCap: TextView

    private fun Int.dp() = dpi(this)

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top.dp() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 56.dp(), 22.dp(), 28.dp())
        }

        root.addView(TextView(this).apply {
            text = "Neggaza"; textSize = 36f; setTextColor(Theme.TEXT)
            setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
        }, lp())
        root.addView(TextView(this).apply {
            text = "مساعد القفز الذكي"; textSize = 14f; setTextColor(Theme.SUB); gravity = Gravity.CENTER
        }, lp(2))

        // بطاقة الحالة
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18.dp(), 14.dp(), 18.dp(), 14.dp())
            background = Theme.shape(Theme.CARD, 20.dp().toFloat(), Theme.LINE, 1.dp())
        }
        chipOv = chip(); chipAcc = chip(); chipCap = chip()
        card.addView(row("الظهور فوق التطبيقات", chipOv))
        card.addView(row("خدمة الوصول", chipAcc), lp(10))
        card.addView(row("الالتقاط", chipCap), lp(10))
        root.addView(card, lp(28))

        root.addView(btn("1   السماح بالظهور فوق التطبيقات", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(22))
        root.addView(btn("2   تفعيل خدمة الوصول (Neggaza)", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(10))
        root.addView(btn("3   بدء Neggaza", true) { start() }, lp(10))
        root.addView(btn("إيقاف", false) {
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        }, lp(10))

        root.addView(TextView(this).apply {
            textSize = 13f; setTextColor(Theme.SUB); setLineSpacing(4f, 1f)
            text = "بعد البدء افتح اللعبة وستظهر أيقونة N عائمة.\n" +
                    "• اضغط الأيقونة لفتح القائمة (ابدأ/إيقاف، معايرة ذاتية).\n" +
                    "• الزران − و + تحت الأيقونة يضبطان قوة الضغط بالنسبة للمسافة.\n" +
                    "• الإطار الأخضر = القطعة القادمة، والأصفر = القطعة الحالية، والدائرة الحمراء = اللاعب."
        }, lp(24))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Theme.BG); isFillViewport = true; addView(root)
        })
    }

    private fun chip() = TextView(this).apply {
        textSize = 12f; setPadding(12.dp(), 4.dp(), 12.dp(), 4.dp())
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun row(label: String, chip: TextView) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(TextView(context).apply { text = label; textSize = 15f; setTextColor(Theme.TEXT) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(chip)
    }

    private fun btn(t: String, primary: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) Theme.ON_ACCENT else Theme.TEXT)
        setPadding(16.dp(), 15.dp(), 16.dp(), 15.dp())
        background = if (primary) Theme.shape(Theme.ACCENT, 16.dp().toFloat())
        else Theme.shape(Theme.CARD2, 16.dp().toFloat(), Theme.LINE, 1.dp())
        setOnClickListener { f() }
    }

    private fun setChip(c: TextView, ok: Boolean, yes: String, no: String) {
        c.text = if (ok) yes else no
        c.setTextColor(if (ok) Theme.OK_FG else Theme.BAD_FG)
        c.background = Theme.shape(if (ok) Theme.OK_BG else Theme.BAD_BG, 20.dp().toFloat())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        setChip(chipOv, Settings.canDrawOverlays(this), "مفعّل", "غير مفعّل")
        setChip(chipAcc, BotAccessibilityService.instance != null, "مفعّلة", "غير مفعّلة")
        setChip(chipCap, CaptureService.running, "يعمل", "متوقف")
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { toast("فعّل الخطوة 1 أولاً"); return }
        if (BotAccessibilityService.instance == null) { toast("فعّل الخطوة 2 أولاً"); return }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            )
            toast("تم البدء — افتح اللعبة")
            moveTaskToBack(true)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
