package com.example.jumpbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** طبقة الرسم: إطار أخضر دقيق حول القطع الأمامية + خط من اللاعب للهدف. */
class OverlayView(c: Context) : View(c) {
    var res: Analysis? = null
    var scale = 2f
    var label = ""

    private fun stroke(col: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col; style = Paint.Style.STROKE; strokeWidth = w
        strokeJoin = Paint.Join.ROUND
    }
    private val green = stroke(Color.rgb(0, 230, 118), 4f)
    private val greenBold = stroke(Color.rgb(0, 255, 110), 9f)
    private val greenFill = Paint().apply { color = Color.argb(60, 0, 230, 118); style = Paint.Style.FILL }
    private val yellow = stroke(Color.rgb(255, 214, 0), 5f)
    private val thin = stroke(Color.argb(150, 255, 255, 255), 2.5f)
    private val red = stroke(Color.rgb(255, 82, 82), 7f)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 40f; isFakeBoldText = true
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()

    private fun diamond(c: Canvas, b: Box, s: Float, p: Paint) {
        val w = b.w.toFloat()
        path.reset()
        path.moveTo(b.cx * s, b.y0 * s)
        path.lineTo(b.x1 * s, (b.y0 + w / 4f) * s)
        path.lineTo(b.cx * s, (b.y0 + w / 2f) * s)
        path.lineTo(b.x0 * s, (b.y0 + w / 4f) * s)
        path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val a = res ?: return
        val s = scale
        val px = a.px * s; val py = a.py * s
        a.cur?.let { diamond(c, it, s, yellow) }
        for (b in a.ahead) {
            c.drawRect(b.x0 * s, b.y0 * s, b.x1 * s, b.y1 * s, green)
            diamond(c, b, s, green)
            c.drawLine(px, py, b.cx * s, b.cy * s, thin)
        }
        a.target?.let {
            c.drawRect(it.x0 * s, it.y0 * s, it.x1 * s, it.y1 * s, greenBold)
            path.reset()
            diamond(c, it, s, greenFill.apply { style = Paint.Style.FILL })
            c.drawLine(px, py, it.cx * s, it.cy * s, greenBold)
            c.drawCircle(it.cx * s, it.cy * s, 12f, greenBold)
            c.drawText(label, (px + it.cx * s) / 2f + 18f, (py + it.cy * s) / 2f, text)
        }
        c.drawCircle(px, py, 18f, red)
    }
}
