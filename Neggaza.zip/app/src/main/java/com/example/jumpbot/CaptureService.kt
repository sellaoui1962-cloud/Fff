package com.example.jumpbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.hypot

class CaptureService : Service() {

    companion object {
        @Volatile var running = false
    }

    private class Prev(val d: Float)

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var imgThread: HandlerThread? = null
    private var worker: Thread? = null
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences

    private var overlay: OverlayView? = null
    private var ctrl: LinearLayout? = null
    private var ctrlLp: WindowManager.LayoutParams? = null
    private var menu: LinearLayout? = null
    private var info: TextView? = null
    private var startBtn: TextView? = null
    private var learnBtn: TextView? = null
    private var toast: Toast? = null

    @Volatile private var frame: IntArray? = null
    @Volatile private var frameTime = 0L
    @Volatile private var alive = false
    @Volatile private var botOn = false
    @Volatile private var learn = false
    @Volatile private var k = 1500f       // مللي ثانية لكل (المسافة ÷ عرض الشاشة)
    @Volatile private var last = ""
    @Volatile private var mask: IntArray? = null

    private var sw = 0; private var sh = 0
    private var fw = 0; private var fh = 0

    private fun Int.dp() = dpi(this)

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (running) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        prefs = getSharedPreferences("neggaza", Context.MODE_PRIVATE)
        k = prefs.getFloat("k", 1500f)
        learn = prefs.getBoolean("learn", false)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        fw = sw / 2; fh = sh / 2

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        imgThread = HandlerThread("img").also { it.start() }
        reader = ImageReader.newInstance(fw, fh, PixelFormat.RGBA_8888, 3).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                    ?: return@setOnImageAvailableListener
                try {
                    val pl = img.planes[0]
                    val buf = pl.buffer
                    val rs = pl.rowStride; val ps = pl.pixelStride
                    val out = IntArray(fw * fh)
                    for (y in 0 until fh) {
                        var o = y * rs
                        for (x in 0 until fw) {
                            val r8 = buf.get(o).toInt() and 255
                            val g8 = buf.get(o + 1).toInt() and 255
                            val b8 = buf.get(o + 2).toInt() and 255
                            out[y * fw + x] = (255 shl 24) or (r8 shl 16) or (g8 shl 8) or b8
                            o += ps
                        }
                    }
                    frame = out
                    frameTime = SystemClock.uptimeMillis()
                } finally { img.close() }
            }, Handler(imgThread!!.looper))
        }
        vd = projection!!.createVirtualDisplay(
            "neggaza", fw, fh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        buildOverlay()
        buildControls()
        running = true
        alive = true
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ng", "Neggaza", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ng")
            .setContentTitle("Neggaza يعمل")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ------------------------------------------------------------ الواجهة
    private fun buildOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        overlay = v
    }

    private fun pill(t: String, bg: Int, fg: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; setTextColor(fg); textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
        background = Theme.shape(bg, 12.dp().toFloat())
        setOnClickListener { onClick() }
    }

    private fun buildControls() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val glass = Color.argb(235, 38, 41, 46)

        // الأيقونة العائمة
        val bubble = TextView(this).apply {
            text = "N"; gravity = Gravity.CENTER; textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Theme.TEXT)
            background = Theme.oval(glass, Theme.ACCENT, 2.dp())
        }
        root.addView(bubble, LinearLayout.LayoutParams(54.dp(), 54.dp()))

        // زران صغيران تحت الأيقونة: − و + لقوة الضغط
        val mini = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun miniBtn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; textSize = 17f; setTextColor(Theme.TEXT)
            background = Theme.oval(glass, Theme.LINE, 1.dp())
            setOnClickListener { f() }
        }
        val mlp = { LinearLayout.LayoutParams(36.dp(), 36.dp()).apply { setMargins(3.dp(), 6.dp(), 3.dp(), 0) } }
        mini.addView(miniBtn("−") { adjustK(0.96f) }, mlp())
        mini.addView(miniBtn("+") { adjustK(1.04f) }, mlp())
        root.addView(mini)

        // القائمة (تفتح عند الضغط على الأيقونة)
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
            background = Theme.shape(Color.argb(240, 33, 35, 39), 18.dp().toFloat(), Theme.LINE, 1.dp())
            visibility = View.GONE
        }
        info = TextView(this).apply { setTextColor(Theme.SUB); textSize = 11f; gravity = Gravity.CENTER }
        m.addView(info)
        fun gap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = 8.dp() }
        startBtn = pill("▶  ابدأ", Theme.ACCENT, Theme.ON_ACCENT) { toggleBot() }
        m.addView(startBtn, gap())
        learnBtn = pill(learnText(), Theme.CARD2, Theme.TEXT) {
            learn = !learn
            prefs.edit().putBoolean("learn", learn).apply()
            learnBtn?.text = learnText()
        }
        m.addView(learnBtn, gap())
        m.addView(pill("إيقاف Neggaza", Theme.CARD2, Theme.BAD_FG) { stopSelf() }, gap())
        root.addView(m, LinearLayout.LayoutParams(200.dp(), LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = 8.dp() })
        menu = m

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = sw - 80.dp(); lp.y = 200.dp()
        wm.addView(root, lp)
        ctrl = root; ctrlLp = lp

        // السحب والنقر على الأيقونة
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var drag = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; drag = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (!drag && hypot(dx, dy) > 12.dp()) drag = true
                        if (drag) {
                            lp.x = (ox + dx).toInt(); lp.y = (oy + dy).toInt()
                            wm.updateViewLayout(root, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!drag) toggleMenu()
                }
                return true
            }
        })
        refreshInfo()
    }

    private fun learnText() = if (learn) "معايرة ذاتية: تعمل" else "معايرة ذاتية: متوقفة"

    private fun toggleMenu() {
        val m = menu ?: return
        val lp = ctrlLp ?: return
        if (m.visibility == View.VISIBLE) m.visibility = View.GONE
        else {
            m.visibility = View.VISIBLE
            val maxX = sw - 210.dp()
            if (lp.x > maxX) lp.x = maxX
        }
        ctrl?.let { wm.updateViewLayout(it, lp) }
    }

    private fun toggleBot() {
        botOn = !botOn
        startBtn?.text = if (botOn) "⏸  إيقاف مؤقت" else "▶  ابدأ"
        if (botOn) toggleMenu()
    }

    private fun adjustK(f: Float) {
        k = (k * f).coerceIn(300f, 4000f)
        prefs.edit().putFloat("k", k).apply()
        refreshInfo()
        toast?.cancel()
        toast = Toast.makeText(this, "قوة الضغط ${k.toInt()}", Toast.LENGTH_SHORT).also { it.show() }
    }

    private fun refreshInfo() {
        main.post { info?.text = "قوة الضغط ${k.toInt()}\n$last" }
    }

    // ------------------------------------------------------------ الحلقة الرئيسية
    /** يخفي طبقة الرسم ويحسب مستطيل الأيقونة (لتجاهله) ثم يأخذ لقطة نظيفة. */
    private fun grab(): IntArray? {
        val latch = CountDownLatch(1)
        main.post {
            overlay?.visibility = View.INVISIBLE
            ctrl?.let { c ->
                val loc = IntArray(2)
                c.getLocationOnScreen(loc)
                mask = intArrayOf((loc[0] - 14) / 2, (loc[1] - 14) / 2,
                    (loc[0] + c.width + 14) / 2, (loc[1] + c.height + 14) / 2)
            }
            latch.countDown()
        }
        latch.await(500, TimeUnit.MILLISECONDS)
        val t = SystemClock.uptimeMillis()
        var waited = 0
        while (frameTime < t + 50 && waited < 600) { Thread.sleep(20); waited += 20 }
        return frame
    }

    private fun show(a: Analysis?, label: String) {
        main.post {
            overlay?.let {
                it.res = a; it.scale = sw.toFloat() / fw; it.label = label
                it.visibility = View.VISIBLE
                it.invalidate()
            }
        }
    }

    private fun loop() {
        var stable = 0
        var lastPx = -1f; var lastPy = -1f
        var prev: Prev? = null
        val pressX = sw * 0.5f
        val pressY = sh * 0.80f

        while (alive) {
            try {
                val f = grab()
                if (f == null) { Thread.sleep(300); continue }

                if (botOn) {
                    val b = Detector.gameOverButton(f, fw, fh)
                    if (b != null) {
                        last = "بدء/إعادة اللعب"; refreshInfo()
                        BotAccessibilityService.hold(b.first * 2f, b.second * 2f, 60)
                        Thread.sleep(2500)
                        prev = null; stable = 0
                        continue
                    }
                }

                val a = Detector.analyze(f, fw, fh, mask)
                val target = a?.target
                if (a == null || target == null) {
                    show(a, ""); stable = 0
                    last = "لا أجد اللاعب/الهدف"; refreshInfo()
                    Thread.sleep(250); continue
                }

                val dist = hypot(target.cx - a.px, target.cy - a.py) / fw
                val moved = hypot(a.px - lastPx, a.py - lastPy)
                lastPx = a.px; lastPy = a.py
                stable = if (moved < 3f) stable + 1 else 0

                // معايرة ذاتية اختيارية
                val p = prev
                if (learn && p != null && a.below != null && stable >= 1) {
                    val actual = hypot(a.px - a.below.cx, a.py - a.below.cy) / fw
                    if (actual in 0.12f..1.2f) {
                        val ratio = p.d / actual
                        if (ratio in 0.65f..1.5f) {
                            k = (0.8f * k + 0.2f * k * ratio).coerceIn(300f, 4000f)
                            prefs.edit().putFloat("k", k).apply()
                        }
                    }
                    prev = null
                }

                val ms = (k * dist).coerceIn(80f, 3500f)
                show(a, "${ms.toInt()}ms")
                last = "المسافة ${(dist * 100).toInt()}%  •  ${ms.toInt()}ms"
                refreshInfo()

                if (!botOn || stable < 2) { Thread.sleep(150); continue }

                if (!BotAccessibilityService.hold(pressX, pressY, ms.toLong())) {
                    last = "فعّل خدمة الوصول!"; refreshInfo(); Thread.sleep(1000); continue
                }
                prev = Prev(dist)
                stable = 0
                Thread.sleep(1100)
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                last = "خطأ: ${e.javaClass.simpleName}"; refreshInfo()
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            }
        }
    }

    override fun onDestroy() {
        alive = false
        running = false
        worker?.interrupt()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { ctrl?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        imgThread?.quitSafely()
        super.onDestroy()
    }
}
